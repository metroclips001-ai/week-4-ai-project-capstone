# Iris Species Prediction API — End-to-End ML Deployment (Capstone)

An end-to-end machine learning project: data preprocessing → model training →
testing → serialization → deployment as a REST API with Flask.

## Project Structure

```
iris-ml-deployment/
├── data/
│   └── iris_raw.csv          # dataset (auto-generated on first run)
├── models/
│   ├── model.pkl              # trained model (pickle)
│   ├── model.joblib            # trained model (joblib copy)
│   ├── scaler.joblib            # fitted StandardScaler
│   ├── label_encoder.joblib      # fitted LabelEncoder
│   └── feature_names.joblib       # column order used at training time
├── templates/
│   └── index.html               # simple browser UI for the API
├── tests/
│   └── test_api.py               # unit + API tests
├── preprocess.py                  # data cleaning, encoding, scaling, split
├── train.py                        # model training, evaluation, serialization
├── app.py                           # Flask app / prediction API
├── requirements.txt
└── README.md
```

## Dataset

The classic Iris flower dataset (150 samples, 3 species: setosa, versicolor,
virginica; 4 numeric features: sepal length/width, petal length/width),
loaded via scikit-learn and saved locally as `data/iris_raw.csv`.

## 1. Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Preprocess + Train + Evaluate + Serialize

```bash
python train.py
```

This runs `preprocess.py` internally (cleaning, label encoding, scaling,
80/20 train-test split), trains a `RandomForestClassifier`, prints accuracy /
precision / recall / F1 / confusion matrix, and saves the model to
`models/model.pkl` (pickle) and `models/model.joblib` (joblib).

Typical result: ~96–97% test accuracy.

## 3. Run the API

```bash
python app.py
```

Visit `http://127.0.0.1:5000/` for a browser form, or call the JSON API directly:

```bash
curl -X POST http://127.0.0.1:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"sepal length (cm)":5.1,"sepal width (cm)":3.5,"petal length (cm)":1.4,"petal width (cm)":0.2}'
```

Response:

```json
{
  "prediction": "setosa",
  "probabilities": {"setosa": 1.0, "versicolor": 0.0, "virginica": 0.0}
}
```

## 4. Run Tests

```bash
python tests/test_api.py
```

## Tech Stack

Python, scikit-learn, pandas, Flask, Pickle/Joblib.

## Notes

- The scaler and label encoder are serialized alongside the model so the
  exact same preprocessing is applied at inference time as at training time.
- `/health` endpoint provided for basic uptime/monitoring checks.
- For production deployment, run behind a WSGI server (e.g. `gunicorn app:app`)
  rather than Flask's built-in dev server.
