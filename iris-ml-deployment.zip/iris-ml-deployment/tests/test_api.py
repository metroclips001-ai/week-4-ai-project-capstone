"""
test_api.py
-----------
Basic tests for the trained model and the Flask prediction API.
Run with:  python -m pytest tests/test_api.py -v
(or simply: python tests/test_api.py)
"""

import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import app, make_prediction  # noqa: E402


SAMPLE_INPUT = {
    "sepal length (cm)": 5.1,
    "sepal width (cm)": 3.5,
    "petal length (cm)": 1.4,
    "petal width (cm)": 0.2,
}


def test_make_prediction_returns_valid_species():
    result = make_prediction(SAMPLE_INPUT)
    assert "prediction" in result
    assert result["prediction"] in ("setosa", "versicolor", "virginica")
    assert abs(sum(result["probabilities"].values()) - 1.0) < 0.01


def test_health_endpoint():
    client = app.test_client()
    response = client.get("/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"


def test_predict_endpoint_success():
    client = app.test_client()
    response = client.post(
        "/predict",
        data=json.dumps(SAMPLE_INPUT),
        content_type="application/json",
    )
    assert response.status_code == 200
    data = response.get_json()
    assert "prediction" in data


def test_predict_endpoint_missing_field():
    client = app.test_client()
    bad_input = {"sepal length (cm)": 5.1}
    response = client.post(
        "/predict",
        data=json.dumps(bad_input),
        content_type="application/json",
    )
    assert response.status_code == 400
    assert "error" in response.get_json()


if __name__ == "__main__":
    test_make_prediction_returns_valid_species()
    test_health_endpoint()
    test_predict_endpoint_success()
    test_predict_endpoint_missing_field()
    print("All tests passed.")
