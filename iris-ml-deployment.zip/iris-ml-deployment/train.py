"""
train.py
--------
Trains a classification model on the preprocessed Iris data, evaluates it,
and serializes the final model to disk using pickle (models/model.pkl).

Run:
    python train.py
"""

import os
import pickle
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

from preprocess import preprocess_and_split

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(MODELS_DIR, exist_ok=True)


def train_model():
    X_train, X_test, y_train, y_test, features = preprocess_and_split()

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=5,
        random_state=42,
    )
    model.fit(X_train, y_train)

    return model, X_test, y_test, features


def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision_macro": precision_score(y_test, y_pred, average="macro"),
        "recall_macro": recall_score(y_test, y_pred, average="macro"),
        "f1_macro": f1_score(y_test, y_pred, average="macro"),
    }

    print("=== Test Set Evaluation ===")
    for k, v in metrics.items():
        print(f"{k}: {v:.4f}")

    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    return metrics


def save_model(model, path=os.path.join(MODELS_DIR, "model.pkl")):
    """Serialize the trained model with pickle."""
    with open(path, "wb") as f:
        pickle.dump(model, f)
    print(f"\nModel serialized with pickle -> {path}")

    # Also save a joblib copy to demonstrate both serialization methods
    joblib_path = os.path.join(MODELS_DIR, "model.joblib")
    joblib.dump(model, joblib_path)
    print(f"Model also serialized with joblib -> {joblib_path}")


if __name__ == "__main__":
    model, X_test, y_test, features = train_model()
    evaluate_model(model, X_test, y_test)
    save_model(model)
