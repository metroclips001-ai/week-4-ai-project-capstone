"""
app.py
------
Flask application that deploys the trained Iris classifier as a REST API,
plus a small HTML form for manual/browser-based testing.

Endpoints:
    GET  /            -> HTML form for manual prediction
    POST /predict      -> JSON API. Body: {"sepal_length":..,"sepal_width":..,
                                            "petal_length":..,"petal_width":..}
    GET  /health        -> simple health check

Run:
    python app.py
Then visit http://127.0.0.1:5000/
"""

import os
import pickle
import joblib
import pandas as pd
from flask import Flask, request, jsonify, render_template

BASE_DIR = os.path.dirname(__file__)
MODELS_DIR = os.path.join(BASE_DIR, "models")

app = Flask(__name__)

# ---- Load serialized artifacts once at startup ----
with open(os.path.join(MODELS_DIR, "model.pkl"), "rb") as f:
    model = pickle.load(f)

scaler = joblib.load(os.path.join(MODELS_DIR, "scaler.joblib"))
label_encoder = joblib.load(os.path.join(MODELS_DIR, "label_encoder.joblib"))
feature_names = joblib.load(os.path.join(MODELS_DIR, "feature_names.joblib"))


def make_prediction(payload: dict):
    """Validate input, scale it exactly like training, and return the
    predicted class plus per-class probabilities."""
    missing = [f for f in feature_names if f not in payload]
    if missing:
        raise ValueError(f"Missing required fields: {missing}")

    ordered_values = pd.DataFrame(
        [[float(payload[f]) for f in feature_names]], columns=feature_names
    )
    scaled = scaler.transform(ordered_values)

    pred_encoded = model.predict(scaled)[0]
    pred_label = label_encoder.inverse_transform([pred_encoded])[0]
    probabilities = model.predict_proba(scaled)[0]

    return {
        "prediction": pred_label,
        "probabilities": {
            label_encoder.inverse_transform([i])[0]: round(float(p), 4)
            for i, p in enumerate(probabilities)
        },
    }


@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", feature_names=feature_names, result=None)


@app.route("/predict-form", methods=["POST"])
def predict_form():
    """Handles the HTML form submission (browser use)."""
    try:
        payload = {f: request.form.get(f) for f in feature_names}
        result = make_prediction(payload)
    except Exception as e:
        result = {"error": str(e)}
    return render_template("index.html", feature_names=feature_names, result=result)


@app.route("/predict", methods=["POST"])
def predict_api():
    """JSON REST API endpoint for programmatic use."""
    try:
        payload = request.get_json(force=True)
        result = make_prediction(payload)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
