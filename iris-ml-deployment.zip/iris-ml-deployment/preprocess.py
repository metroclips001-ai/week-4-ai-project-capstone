"""
preprocess.py
--------------
Data preprocessing module for the Iris Species Prediction project.

Responsibilities:
1. Load the raw dataset.
2. Handle missing values (defensive, in case a custom CSV is supplied later).
3. Split features (X) and target (y).
4. Encode the target labels.
5. Scale the numeric features using StandardScaler.
6. Split into train and test sets.
7. Persist the fitted scaler and label encoder to disk so the exact same
   transformation can be reproduced at prediction time by the Flask API.
"""

import os
import joblib
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)


def load_raw_data() -> pd.DataFrame:
    """Load the Iris dataset into a pandas DataFrame and save a raw CSV copy
    so the project has an actual data file (useful for the report/demo)."""
    iris = load_iris(as_frame=True)
    df = iris.frame.copy()
    df.rename(columns={"target": "species"}, inplace=True)
    df["species"] = df["species"].map(dict(enumerate(iris.target_names)))
    df.to_csv(os.path.join(DATA_DIR, "iris_raw.csv"), index=False)
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop exact duplicates and handle any missing values."""
    df = df.drop_duplicates().reset_index(drop=True)
    if df.isnull().sum().sum() > 0:
        df = df.fillna(df.mean(numeric_only=True))
    return df


def preprocess_and_split(test_size: float = 0.2, random_state: int = 42):
    """Full preprocessing pipeline. Returns train/test splits ready for
    model training, and saves the scaler + label encoder for reuse."""
    df = load_raw_data()
    df = clean_data(df)

    X = df.drop(columns=["species"])
    y = df["species"]

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=test_size, random_state=random_state, stratify=y_encoded
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    joblib.dump(scaler, os.path.join(MODELS_DIR, "scaler.joblib"))
    joblib.dump(label_encoder, os.path.join(MODELS_DIR, "label_encoder.joblib"))
    joblib.dump(list(X.columns), os.path.join(MODELS_DIR, "feature_names.joblib"))

    return X_train_scaled, X_test_scaled, y_train, y_test, list(X.columns)


if __name__ == "__main__":
    X_train, X_test, y_train, y_test, features = preprocess_and_split()
    print("Preprocessing complete.")
    print(f"Features: {features}")
    print(f"Train shape: {X_train.shape}, Test shape: {X_test.shape}")
